
<h1>Hi there, I am <a href="https://rohandas28.github.io" target="_blank">Rohan</a> 🙋🏽‍♂️</h1> 

![](https://visitor-badge.glitch.me/badge?page_id=rohandas28) 

<img align='right' src="https://media.giphy.com/media/M9gbBd9nbDrOTu1Mqx/giphy.gif" width="230">


I'm an enthusiastic Techie and a Developer who loves to contribute to the Opensource Community. 

---

 ## My Skills <img alt="Computer" width="40px" src="/Assets/desktop.png"/>

 **Languages**
 
 <img alt="Python" width="30px" src="/Assets/python.png"/>|<img alt="C" width="30px" src="/Assets/c-programming.png"/>|<img alt="C++" width="30px" src="/Assets/c++.png"/>|<img alt="Java" width="30px" src="/Assets/java.png"/>|<img alt="HTML" width="30px" src="/Assets/html.png"/>|<img alt="CSS" width="30px" src="/Assets/css-3.png"/>|<img alt="JavaScript" width="30px" src="/Assets/javascript.png"/>
 |--|--|--|--|--|--|--|
 
 **Frameworks**
 
 <img alt="nextjs" width="30px" src="/Assets/next.png"/>|<img alt="tailwindcss" width="30px" src="/Assets/tailwindcss-icon.svg"/>|<img alt="Bootstrap" width="30px" src="/Assets/bootstrap-logo.png"/>|<img alt="Bulma" width="30px" src="/Assets/bulma.svg"/>
 |--|--|--|--|
 
 **Tools**
 
 <img alt="Ubuntu" width="30px" src="/Assets/ubuntu.png"/>|<img alt="Linux" width="30px" src="/Assets/linux.png"/>|<img alt="Git" width="30px" src="/Assets/git.png"/>|<img alt="VSCode" width="30px" src="/Assets/vscode.png"/>|
 |--|--|--|--|
 
 **Designing and Photo Editing**
 
<img alt="Adobe Photoshop" width="30px" src="/Assets/photoshop.png"/>|<img alt="Adobe Lightroom" width="30px" src="/Assets/lightroom.png"/>|<img alt="Gimp" width="30px" src="/Assets/gimp-icon.svg"/>
 |--|--|--|

**Audio & Video Editing**

<img alt="Adobe Premiere Pro" width="30px" src="/Assets/premier.png"/>|<img alt="Adobe After Effects" width="30px" src="/Assets/after-effects.png"/>|<img alt="Sony Vegas" width="30px" src="/Assets/vegas.png"/>|<img alt="Adobe Audition" width="30px" src="/Assets/audition.png"/>|<img alt="Audacity" width="30px" src="/Assets/Audacity_Logo_nofilter.svg"/>
|--|--|--|--|--|

 **Connect with Me**
---
[<img align="left" alt="Rohan Das" width="30px" src="https://rohandas28.github.io/avatar.png" />](https://rohandas28.github.io/links) [<img align="left" alt="Twitter - Rohan Das" width="30px" src="/Assets/twitter.png" />](https://twitter.com/rohandas28) [<img align="left" alt="Instagram - Rohan Das" width="30px" src="/Assets/instagram.png" />](https://www.instagram.com/RohanDasRD) [<img align="left" alt="LinkedIn - Rohan Das" width="30px" src="/Assets/linkedin.png" />](https://www.linkedin.com/in/rohandas28) [<img align="left" alt="YouTube -Rohan Das" width="30px" src="/Assets/youtube.png" />](https://www.youtube.com/c/RohanDasTech) [<img align="left" alt="Email -Rohan Das" width="30px" src="/Assets/gmail.png" />](mailto:rohandasbirbhum@gmail.com)

